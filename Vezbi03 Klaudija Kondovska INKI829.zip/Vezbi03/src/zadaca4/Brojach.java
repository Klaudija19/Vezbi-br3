package zadaca4;

public class Brojach {
public int brojach;
	
	public void zgolemi(){
		this.brojach++;
	}
	
	public void reset(){
		this.brojach=0;
	}
	

}

