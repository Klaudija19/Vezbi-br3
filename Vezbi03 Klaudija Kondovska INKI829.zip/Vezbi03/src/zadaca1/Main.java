package zadaca1;

public class Main {
	
	public static void main (String[]args) {
		Avtomobil av = new Avtomobil ("Toyota", "Corolla", "Bela", 12400, 2013, "BT-0001-AA");
		
		av.prvMetod();
		System.out.println(av.vtorMetod());
		}
	}
